package com.project.jfsd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.jfsd.model.Questions;
import com.project.jfsd.repository.QuestionsRepository;
@Service
public class QuestionsServiceImpl implements QuestionsService {
 
	@Autowired
	private QuestionsRepository questionsrepo;
	@Override
	public Questions addQuestions(Questions questions) {
		return questionsrepo.save(questions);
	}

}
