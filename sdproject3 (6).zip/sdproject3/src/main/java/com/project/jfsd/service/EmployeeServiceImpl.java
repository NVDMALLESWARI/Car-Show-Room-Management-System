package com.project.jfsd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.jfsd.model.Assign;
import com.project.jfsd.model.Employee;
import com.project.jfsd.repository.AssignRepository;
import com.project.jfsd.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeerepo;
	
	@Autowired
	private AssignRepository assignrepo;
	@Override
	public Employee checkemplogin(String uname, String pwd) 
	{
		
		return employeerepo.checkemplogin(uname, pwd);
	}
	@Override
	public void deleteService(int id) {
		assignrepo.deleteById(id);
		
	}
	@Override
	public List<Assign> viewallbookings() {
		return (List<Assign>) assignrepo.findAll();
	}

}
