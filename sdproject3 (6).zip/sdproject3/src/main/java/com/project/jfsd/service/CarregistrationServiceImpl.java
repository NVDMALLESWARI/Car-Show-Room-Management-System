package com.project.jfsd.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.project.jfsd.model.Carregistration;
import com.project.jfsd.repository.CarregistrationRepository;

@Service
public class CarregistrationServiceImpl implements CarregistrationService {
	@Autowired
	private CarregistrationRepository carregistrationrepo;

	@Override
	public Carregistration addReg(Carregistration car) {
		return carregistrationrepo.save(car);
	}

	}
