package com.project.jfsd.service;

import com.project.jfsd.model.Carregistration;


public interface CarregistrationService {
	public Carregistration addReg(Carregistration car);

}
