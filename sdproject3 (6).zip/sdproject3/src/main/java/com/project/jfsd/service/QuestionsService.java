package com.project.jfsd.service;

import org.springframework.stereotype.Service;

import com.project.jfsd.model.Questions;

@Service
public interface QuestionsService {
	public Questions addQuestions(Questions questions);
}
