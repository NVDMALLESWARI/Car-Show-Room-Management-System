package com.project.jfsd.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.jfsd.model.Assign;
import com.project.jfsd.model.Employee;
@Service
public interface EmployeeService {
	public Employee checkemplogin(String uname,String pwd);
	public void deleteService(int id);
	public List<Assign> viewallbookings();

}
