package com.project.jfsd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.project.jfsd.model.Admin;
import com.project.jfsd.model.Assign;
import com.project.jfsd.model.Carregistration;
import com.project.jfsd.model.Customer;
import com.project.jfsd.model.Employee;
import com.project.jfsd.model.Questions;
import com.project.jfsd.repository.AdminRepository;
import com.project.jfsd.repository.AssignRepository;
import com.project.jfsd.repository.CarregistrationRepository;
import com.project.jfsd.repository.CustomerRepository;
import com.project.jfsd.repository.EmployeeRepository;
import com.project.jfsd.repository.QuestionsRepository;


@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminRepository adminRespository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CarregistrationRepository carregistrationrepo;
	
	@Autowired
	private EmployeeRepository employeerepository;
	@Autowired
	private AssignRepository assignrepository;
    
	@Autowired
	private QuestionsRepository questionsrepo;
	@Override
	public Assign addService(Assign assign) {
		return assignrepository.save(assign);
	}
	@Override
	public Admin checkadminlogin(String uname,String pwd)
	{
		return adminRespository.checkadminlogin(uname, pwd);
	}
	@Override
	public List<Customer> viewallCustomer()
	{
		
		return (List<Customer>) customerRepository.findAll();
	}
	@Override
	public List<Employee> viewallemployees()
	{
		
		return (List<Employee>) employeerepository.findAll();
	}
	@Override
	public void deletecustomer(int id)
	{
		
	 customerRepository.deleteById(id);
		
	}
	
	@Override
	public void deletecar(int id) 
	{
		carregistrationrepo.deleteById(id);
		
	}
	@Override
	public List<Carregistration> viewallCarreg() {
		
		return (List<Carregistration>) carregistrationrepo.findAll();
	}
	@Override
	public Employee addemployee(Employee employee) {

		return employeerepository.save(employee);
	}
	@Override
	public List<Questions> viewallquestions() {
		return (List<Questions>) questionsrepo.findAll();
	}
	
}
