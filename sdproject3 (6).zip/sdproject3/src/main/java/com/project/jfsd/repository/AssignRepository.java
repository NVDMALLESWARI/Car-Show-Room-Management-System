package com.project.jfsd.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.jfsd.model.Assign;


@Repository
public interface AssignRepository extends CrudRepository<Assign,Integer>{
	

}
