package com.project.jfsd.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="questions")
public class Questions 
{
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private String quiz1;
	private String quiz2;
	private String quiz3;
	private String remarks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQuiz1() {
		return quiz1;
	}
	public void setQuiz1(String quiz1) {
		this.quiz1 = quiz1;
	}
	public String getQuiz2() {
		return quiz2;
	}
	public void setQuiz2(String quiz2) {
		this.quiz2 = quiz2;
	}
	public String getQuiz3() {
		return quiz3;
	}
	public void setQuiz3(String quiz3) {
		this.quiz3 = quiz3;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
