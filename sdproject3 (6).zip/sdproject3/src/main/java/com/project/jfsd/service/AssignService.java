package com.project.jfsd.service;

import org.springframework.stereotype.Service;

import com.project.jfsd.model.Assign;
@Service
public interface AssignService {
	

}
