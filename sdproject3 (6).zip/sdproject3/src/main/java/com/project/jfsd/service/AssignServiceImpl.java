package com.project.jfsd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.jfsd.model.Assign;
import com.project.jfsd.repository.AssignRepository;
@Service
public class AssignServiceImpl implements AssignService{
	

}
