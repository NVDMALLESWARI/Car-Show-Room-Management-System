package com.project.jfsd.controller;

import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.jfsd.model.Employee;
import com.project.jfsd.model.Questions;
import com.project.jfsd.model.Admin;
import com.project.jfsd.model.Assign;
import com.project.jfsd.model.Carregistration;
import com.project.jfsd.model.Customer;
import com.project.jfsd.service.AdminService;
import com.project.jfsd.service.CarregistrationService;
import com.project.jfsd.service.CustomerService;
import com.project.jfsd.service.EmployeeService;
import com.project.jfsd.service.QuestionsService;

@Controller
public class ClientController {
	@Autowired
	private AdminService adminservice;
	
	@Autowired
	private CustomerService customerservice;
	
	@Autowired
	private CarregistrationService carregistrationservice;
	@Autowired
	private EmployeeService employeeservice;
	@Autowired
	private QuestionsService questionsservice;
	@GetMapping("/viewcust")
	public ModelAndView viewemployeedemo(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("uname");
		
		Customer cust =  customerservice.viewcustomer(uname);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("profile");
		mv.addObject("cust", cust);
		return mv;
	}
	@GetMapping("/assign")
	public ModelAndView assigndemo()
	{
			 ModelAndView mv = new ModelAndView("assign","booking",new Assign());
			 return mv;
	}
	@GetMapping("/hyundaicarsbooking")
	public ModelAndView hyundaicarsdemo()
	{
			 ModelAndView mv = new ModelAndView("hyundaicarsbooking","car",new Carregistration());
			 return mv;
	}
	@GetMapping("/audicarsbooking")
	public ModelAndView audicarsdemo()
	{
			 ModelAndView mv = new ModelAndView("audicarsbooking","car",new Carregistration());
			 return mv;
	}
	@PostMapping("/addemployee")
	public ModelAndView addemployeedemo(@ModelAttribute("emp") Employee employee)
	{
		adminservice.addemployee(employee); 
		ModelAndView mv = new ModelAndView();
        mv.setViewName("employeeregistration");
        mv.addObject("msg", "Employee Registration Successfully");
        return mv;
		//return "redirect:employeelogin";
	}
	@PostMapping("/addquestions")
	public ModelAndView addquestionsdemo(@ModelAttribute("qns") Questions questions)
	{
		questionsservice.addQuestions(questions); 
		ModelAndView mv = new ModelAndView();
        mv.setViewName("Questions");
        mv.addObject("msg", "submitted");
        return mv;
		//return "redirect:employeelogin";
	}
	@PostMapping("/addbooking")
	public ModelAndView addbookingdemo(@ModelAttribute("booking") Assign assign)
	{
		adminservice.addService(assign); 
		ModelAndView mv = new ModelAndView();
        mv.setViewName("assign");
        mv.addObject("msg", "added Successfully");
        return mv;
		//return "redirect:employeelogin";
	}
	@GetMapping("/viewallemployees")
	public ModelAndView viewallempdemo()
	{
		ModelAndView mv = new ModelAndView("viewallemployees");
		List<Employee> emplist=adminservice.viewallemployees();
		mv.addObject("emplist",emplist);
		return mv;
	}
	@GetMapping("/viewallquestions")
	public ModelAndView viewallqnsdemo()
	{
		ModelAndView mv = new ModelAndView("viewallquestions");
		List<Questions> emplist=adminservice.viewallquestions();
		mv.addObject("emplist",emplist);
		return mv;
	}
	@GetMapping("/submitquestions")
	public ModelAndView questionsdemo()
	{
			 ModelAndView mv = new ModelAndView("Questions","qns",new Questions());
			 return mv;
	}
	@GetMapping("/bookingdetails")
	public ModelAndView bookingdetailsdemo()
	{
		ModelAndView mv = new ModelAndView("bookingdetails");
		List<Assign> emplist=employeeservice.viewallbookings();
		mv.addObject("emplist",emplist);
		return mv;
	}
	
	@GetMapping("/employeeregistration")
	public ModelAndView employeeregdemo()
	{
			 ModelAndView mv = new ModelAndView("employeeregistration","emp",new Employee());
			 return mv;
	}
	@PostMapping("/addaudicars")
	public ModelAndView addaudicarsdemo(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("audicarsbooking");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@PostMapping("/addhyundaicars")
	public ModelAndView addhyundaicarsdemo(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("hyundaicarsbooking");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@GetMapping("/carreg")
	public ModelAndView carregdemo()
	{
			 ModelAndView mv = new ModelAndView("carreg","car",new Carregistration());
			 return mv;
	}
	@GetMapping("/landroverseriesbooking")
	public ModelAndView landroverseriesdemo()
	{
			 ModelAndView mv = new ModelAndView("landroverseriesbooking","car",new Carregistration());
			 return mv;
	}
	@PostMapping("/checkemployeelogin")
	public ModelAndView checkemplogin(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		
		String euname=request.getParameter("euname");
		String epwd=request.getParameter("epwd");
		
		Employee emp = employeeservice.checkemplogin(euname, epwd);
		
		if(emp!=null)
		{
			HttpSession session = request.getSession();
			session.setAttribute("euname", euname);
			mv.setViewName("employeehome");
		}
		else
		{
			mv.setViewName("employeelogin");
			mv.addObject("msg","Login Failed");
		}
		return mv;
	}
	@GetMapping("/employeelogin")
	public ModelAndView employeelogindemo()
	{
		ModelAndView mv = new ModelAndView("employeelogin");
		return mv;
	}
	@GetMapping("/employeehome")
	public ModelAndView employeehomedemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView("emplpoyeehome");
		HttpSession session = request.getSession();
		String euname = (String) session.getAttribute("euname");
		mv.addObject("ename", euname);
		return mv;
	}
	@GetMapping("/hyundaibooking")
	public ModelAndView hyundaibookingdemo()
	{
			 ModelAndView mv = new ModelAndView("hyundaibooking","car",new Carregistration());
			 return mv;
	}
	@GetMapping("/marutiviharabooking")
	public ModelAndView marutiviharabookingdemo()
	{
			 ModelAndView mv = new ModelAndView("marutiviharabooking","car",new Carregistration());
			 return mv;
	}
	@GetMapping("/audibookings")
	public ModelAndView audibookingdemo()
	{
			 ModelAndView mv = new ModelAndView("audibookings","car",new Carregistration());
			 return mv;
	}
	@GetMapping("/hondacity")
	public ModelAndView hondacitydemo()
	{
			 ModelAndView mv = new ModelAndView("hondacity","car",new Carregistration());
			 return mv;
	}
	@PostMapping("/addhyundai")
	public ModelAndView addhyundaidemo(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("hyundaibooking");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@PostMapping("/checkemplogin")
	public ModelAndView checkemplogindemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		
		String euname=request.getParameter("euname");
		String epwd=request.getParameter("epwd");
		
		Employee emp = employeeservice.checkemplogin(euname, epwd);
		
		if(emp!=null)
		{
			HttpSession session = request.getSession();
			session.setAttribute("euname", euname);
			mv.setViewName("employeehome");
		}
		else
		{
			mv.setViewName("employeehome");
			mv.addObject("msg","Login Failed");
		}
		return mv;
	}
	@PostMapping("/addhondacity")
	public ModelAndView addhondacity(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("hondacity");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@PostMapping("/addmarutivihara")
	public ModelAndView addmmarutiviharademo(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("marutiviharabooking");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@PostMapping("/addlandroverseries")
	public ModelAndView addlandroverseriesdemo(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("landroverseriesbooking");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@PostMapping("/addaudi")
	public ModelAndView addaudidemo(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("audibookings");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@PostMapping("/addreg")
	public ModelAndView addcardemo(@ModelAttribute("car") Carregistration car)
	{
		carregistrationservice.addReg(car); 
     	ModelAndView mv = new ModelAndView();
       mv.setViewName("carreg");
       mv.addObject("msg", "Booking done Successfully");
       return mv;
		    
	}
	@GetMapping("/viewallregistrations")
	public ModelAndView viewallcarsdemo()
	{
		ModelAndView mv = new ModelAndView("viewallregistrations");
		List<Carregistration> carlist=adminservice.viewallCarreg();
		mv.addObject("carlist",carlist);
		return mv;
	}
	@GetMapping("/deletecar")
	public String deletecardemo(@RequestParam("id") int id)
	{
		adminservice.deletecar(id);
		return "redirect:viewallregistrations";
	}
	@GetMapping("/deletebooking")
	public String deletebookingdemo(@RequestParam("id") int id)
	{
		employeeservice.deleteService(id);
		return "redirect:bookingdetails";
	}

	@GetMapping("/custreg")
	public ModelAndView customerregdemo()
	{
			 ModelAndView mv = new ModelAndView("registration","cust",new Customer());
			 return mv;
	}
	@PostMapping("/addcustomer")
	public String addcustomerdemo(@ModelAttribute("cust") Customer customer)
	{
		customerservice.addcustomer(customer); 
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("employeeregistration");
//		mv.addObject("msg", "Employee Registration Successfully");
		return "redirect:login";
	}
	@GetMapping("/deletecust")
	public String deleteempdemo(@RequestParam("id") int id)
	{
		adminservice.deletecustomer(id);
		return "redirect:viewallcustomers";
	}

	@GetMapping("/viewallcustomers")
	public ModelAndView viewallempsdemo()
	{
		ModelAndView mv = new ModelAndView("viewallcustomers");
		List<Customer> custlist=adminservice.viewallCustomer();
		mv.addObject("custlist",custlist);
		return mv;
	}
	@GetMapping("/login")
	public ModelAndView customerlogindemo()
	{
		ModelAndView mv = new ModelAndView("login");
		return mv;
	}
	//@PostMapping("/checkcustlogin")
	//public ModelAndView checkcustlogindemo(HttpServletRequest request)
	//{
		//ModelAndView mv = new ModelAndView();
		
		//String uname=request.getParameter("uname");
		//String pwd=request.getParameter("pwd");
		
	
		//Customer cust = customerservice.checkcustlogin(uname, pwd);
		
		//if(cust!=null)
		//{
		//	HttpSession session = request.getSession();
		//	session.setAttribute("uname", uname);
		//	mv.setViewName("index1");
		//}
		//else
		//{
		//	mv.setViewName("login");
		//	mv.addObject("msg","Login Failed");
		//}
		//return mv;
	@PostMapping("/checkcustlogin")
	  public ModelAndView checklogin(HttpServletRequest request,HttpSession sess)
	  {
	    ModelAndView mv =  new ModelAndView();
	    request.getSession();
	    String uname = request.getParameter("uname");
	    String pwd = request.getParameter("pwd");
	    
	    Customer usr=customerservice.checkcustlogin(uname, pwd);
	    
	    if(usr!=null)
	    {
	      if(sess.isNew()) {
	        mv.setViewName("login");
	      }
	      else {
	        sess.setMaxInactiveInterval(03);
	        sess.setAttribute("uname", uname);
	        System.out.println("uname:" + uname);
	        mv.addObject("log","LOG OUT");
	        mv.setViewName("index");
	        mv.addObject("name", uname);
	      }
	      
	      System.out.println(sess.isNew());
	      
	      
	    }
	    else
	    {
	      mv.setViewName("login");
	      mv.addObject("error", "Login Failed");
	    }
	    return mv;
	  }
	
	
	@GetMapping("/")
	public String mainhomedemo()
	{
		return "index";
	}
	@GetMapping("/adminlogin")
	public ModelAndView adminlogindemo()
	{
		ModelAndView mv = new ModelAndView("adminlogin");
		return mv;
	}
	@GetMapping("/adminhome")
	public ModelAndView adminhomedemo()
	{
		ModelAndView mv = new ModelAndView("adminhome");
		return mv;
	}
	@PostMapping("/checkadminlogin")
	public ModelAndView checkadminlogindemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		
		String auname=request.getParameter("auname");
		String apwd=request.getParameter("apwd");
		
		Admin admin = adminservice.checkadminlogin(auname, apwd);
		
		if(admin!=null)
		{
			HttpSession session = request.getSession();
			session.setAttribute("auname", auname);
			mv.setViewName("adminhome");
		}
		else
		{
			mv.setViewName("adminlogin");
			mv.addObject("msg","Login Failed");
		}
		return mv;
	}

}
