package com.project.jfsd.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.jfsd.model.Employee;
@Repository
public interface EmployeeRepository extends CrudRepository<Employee,Integer>{
	@Query("select e from Employee e where username=?1 and password=?2")
	public Employee checkemplogin(String uname,String pwd);

}
